package app.mcmusic

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews

class WidgetWide : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Widgets.updateAll(context)
    }
}

class WidgetBig : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Widgets.updateAll(context)
    }
}

class WidgetStrip : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Widgets.updateAll(context)
    }
}

/** Кнопки виджетов: назад, пауза или играть, вперёд. */
class WidgetActions : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = PlaybackService.exo ?: return
        if (p.mediaItemCount == 0) return
        when (intent.action) {
            Widgets.ACT_PLAY -> if (p.isPlaying) p.pause() else p.play()
            Widgets.ACT_NEXT -> p.seekToNextMediaItem()
            Widgets.ACT_PREV -> p.seekToPreviousMediaItem()
        }
        Widgets.refresh(context)
    }
}

object Widgets {
    const val ACT_PLAY = "app.mcmusic.WIDGET_PLAY"
    const val ACT_NEXT = "app.mcmusic.WIDGET_NEXT"
    const val ACT_PREV = "app.mcmusic.WIDGET_PREV"

    private val handler = Handler(Looper.getMainLooper())
    private var pending = false

    /** Обновление с небольшой задержкой, чтобы не дёргать виджеты на каждое событие. */
    fun refresh(ctx: Context) {
        if (pending) return
        pending = true
        val app = ctx.applicationContext
        handler.postDelayed({
            pending = false
            try {
                updateAll(app)
            } catch (e: Exception) {
                // виджет не критичен
            }
        }, 250)
    }

    fun updateAll(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        update(ctx, mgr, WidgetWide::class.java, R.layout.widget_wide, true, 288)
        update(ctx, mgr, WidgetBig::class.java, R.layout.widget_big, true, 480)
        update(ctx, mgr, WidgetStrip::class.java, R.layout.widget_strip, false, 160)
    }

    private fun update(
        ctx: Context,
        mgr: AppWidgetManager,
        cls: Class<*>,
        layout: Int,
        full: Boolean,
        coverPx: Int
    ) {
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
        if (ids.isEmpty()) return
        mgr.updateAppWidget(ids, build(ctx, layout, full, coverPx))
    }

    private fun flags(): Int = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    private fun openApp(ctx: Context): PendingIntent =
        PendingIntent.getActivity(
            ctx, 100,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags()
        )

    private fun action(ctx: Context, act: String, code: Int): PendingIntent =
        PendingIntent.getBroadcast(ctx, code, Intent(ctx, WidgetActions::class.java).setAction(act), flags())

    private fun fmt(ms: Long): String {
        val s = (if (ms < 0) 0 else ms / 1000).toInt()
        return String.format("%d:%02d", s / 60, s % 60)
    }

    private fun roundedCover(ctx: Context, bytes: ByteArray?, px: Int): Bitmap {
        var src: Bitmap? = null
        if (bytes != null) {
            try {
                src = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            } catch (e: Exception) {
                src = null
            }
        }
        if (src == null) {
            src = BitmapFactory.decodeResource(ctx.resources, R.drawable.art_placeholder)
        }
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val b = src ?: return out
        val s = minOf(b.width, b.height)
        val square = Bitmap.createBitmap(b, (b.width - s) / 2, (b.height - s) / 2, s, s)
        val scaled = Bitmap.createScaledBitmap(square, px, px, true)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val r = px * 0.16f
        Canvas(out).drawRoundRect(RectF(0f, 0f, px.toFloat(), px.toFloat()), r, r, paint)
        return out
    }

    private fun build(ctx: Context, layout: Int, full: Boolean, coverPx: Int): RemoteViews {
        val rv = RemoteViews(ctx.packageName, layout)
        val p = PlaybackService.exo
        val has = p != null && p.mediaItemCount > 0
        var title = "Mcmusic"
        var artist = "Нажми, чтобы открыть"
        var art: ByteArray? = null
        var playing = false
        var pos = 0L
        var dur = 0L
        if (p != null && has) {
            val md = p.mediaMetadata
            val t = md.title?.toString()
            title = if (t.isNullOrBlank()) "Mcmusic" else t
            artist = md.artist?.toString() ?: ""
            art = md.artworkData
            playing = p.isPlaying
            pos = p.currentPosition
            dur = p.duration
            if (dur < 0) dur = 0
        }
        rv.setTextViewText(R.id.wTitle, title)
        rv.setTextViewText(R.id.wArtist, artist)
        rv.setImageViewBitmap(R.id.wCover, roundedCover(ctx, art, coverPx))
        rv.setImageViewResource(R.id.wPlay, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        if (full) {
            val prog = if (dur > 0) ((pos * 1000L) / dur).toInt().coerceIn(0, 1000) else 0
            rv.setProgressBar(R.id.wBar, 1000, prog, false)
            rv.setTextViewText(R.id.wCur, fmt(pos))
            rv.setTextViewText(R.id.wDur, fmt(dur))
        }
        val open = openApp(ctx)
        rv.setOnClickPendingIntent(R.id.wRoot, open)
        rv.setOnClickPendingIntent(R.id.wCover, open)
        if (has) {
            rv.setOnClickPendingIntent(R.id.wPrev, action(ctx, ACT_PREV, 101))
            rv.setOnClickPendingIntent(R.id.wPlay, action(ctx, ACT_PLAY, 102))
            rv.setOnClickPendingIntent(R.id.wNext, action(ctx, ACT_NEXT, 103))
        } else {
            rv.setOnClickPendingIntent(R.id.wPrev, open)
            rv.setOnClickPendingIntent(R.id.wPlay, open)
            rv.setOnClickPendingIntent(R.id.wNext, open)
        }
        return rv
    }
}
