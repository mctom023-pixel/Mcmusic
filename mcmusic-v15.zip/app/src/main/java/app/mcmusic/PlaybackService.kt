package app.mcmusic

import android.app.PendingIntent
import android.content.Context
import android.media.audiofx.BassBoost
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Фоновый сервис: держит плеер и медиа-сессию. Система сама рисует по ней
 * уведомление, виджет на экране блокировки и значок с волной у камеры.
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null

    companion object {
        /** Плеер в том же процессе: нужен окну, чтобы снимать звук для волны. */
        @Volatile
        var exo: ExoPlayer? = null

        @Volatile
        var pan: Pan8D? = null

        @Volatile
        var spatialLevel = 0

        @Volatile
        var bassLevel = 0
        private var bass: BassBoost? = null

        fun setSpatial(level: Int) {
            spatialLevel = level
            pan?.level = level
        }

        fun setBass(level: Int) {
            bassLevel = level
            applyBass()
        }

        private fun applyBass() {
            try {
                bass?.release()
            } catch (e: Exception) {
                // не критично
            }
            bass = null
            if (bassLevel <= 0) return
            try {
                val sid = exo?.audioSessionId ?: return
                if (sid == 0) return
                val b = BassBoost(0, sid)
                if (!b.strengthSupported) {
                    b.release()
                    return
                }
                val st = when (bassLevel) {
                    1 -> 350
                    2 -> 650
                    else -> 1000
                }
                b.setStrength(st.toShort())
                b.setEnabled(true)
                bass = b
            } catch (e: Exception) {
                bass = null
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val panner = Pan8D()
        panner.level = spatialLevel
        pan = panner
        val renderers = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessors(arrayOf<AudioProcessor>(panner))
                    .build()
            }
        }
        val player = ExoPlayer.Builder(this, renderers)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.setRepeatMode(Player.REPEAT_MODE_ALL)
        exo = player
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                Widgets.refresh(this@PlaybackService)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                Widgets.refresh(this@PlaybackService)
            }

            override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                Widgets.refresh(this@PlaybackService)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                Widgets.refresh(this@PlaybackService)
            }
        })
        applyBass()

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player).setSessionActivity(openApp).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.getPlayWhenReady() || p.getMediaItemCount() == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        exo = null
        pan = null
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        try {
            Widgets.updateAll(applicationContext)
        } catch (e: Exception) {
            // не критично
        }
        super.onDestroy()
    }
}
