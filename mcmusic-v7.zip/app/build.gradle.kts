plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.mcmusic"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.mcmusic"
        minSdk = 30
        targetSdk = 34
        versionCode = 7
        versionName = "7.0"
    }

    // Один и тот же ключ для каждой сборки, чтобы новая версия ставилась поверх старой
    signingConfigs {
        getByName("debug") {
            storeFile = rootProject.file("mcmusic.keystore")
            storePassword = "mcmusic"
            keyAlias = "mcmusic"
            keyPassword = "mcmusic"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += "-opt-in=androidx.media3.common.util.UnstableApi"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1")
}
