package app.mcmusic

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.util.Size
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowInsetsController
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.Executors

/**
 * Экран приложения: наш дизайн (index.html) в WebView + мост к Android:
 * список аудио с телефона, воспроизведение, удаление файлов.
 */
class MainActivity : Activity() {

    private class Meta(val title: String, val artist: String, val cover: ByteArray?)
    private class PendingTags(val id: String, val title: String, val artist: String, val cover: ByteArray?)

    private lateinit var web: WebView
    private val main = Handler(Looper.getMainLooper())
    private var controller: MediaController? = null
    private val meta = HashMap<String, Meta>()
    private var pendingDeleteId: String? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var sleepRunnable: Runnable? = null
    private var shuffle = false
    private var speed = 1f
    private var pitch = 1f
    private var viz: Visualizer? = null
    private var waveWanted = false
    private var pageReady = false
    private var visible = false
    private var errCount = 0
    private val io = Executors.newSingleThreadExecutor()
    private val artCache = HashMap<String, ByteArray>()
    private val artTried = HashSet<String>()
    private var pendingTags: PendingTags? = null
    private var repeat = Player.REPEAT_MODE_ALL
    private var notifAsked = false

    companion object {
        const val REQ_PERM = 1
        const val REQ_DELETE = 2
        const val REQ_FILE = 3
        const val REQ_WRITE = 4
        const val REQ_NOTIF = 5
        const val REQ_REC = 6
        private val VOICE_RE = Regex("voice|record|диктофон|запис|звонк|ptt-")
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) errCount = 0
            push()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            push()
            preloadArt()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            push()
        }

        override fun onPlayerError(error: PlaybackException) {
            handleError()
        }
    }

    private val ticker: Runnable = object : Runnable {
        override fun run() {
            if (visible && controller?.isPlaying == true) push()
            main.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        applyBars(true)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.textZoom = 100
        s.setSupportZoom(false)
        web.isVerticalScrollBarEnabled = false
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        web.isLongClickable = false
        web.isHapticFeedbackEnabled = false
        web.setOnLongClickListener { true }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = callback
                return try {
                    startActivityForResult(params!!.createIntent(), REQ_FILE)
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                push()
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        connectController()
        main.post(ticker)
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(playerListener)
                push()
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось запустить плеер", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onResume() {
        super.onResume()
        visible = true
        if (waveWanted) startWave()
        if (pageReady) {
            push()
            js("window.__native&&window.__native.refresh&&window.__native.refresh()")
        }
    }

    override fun onPause() {
        visible = false
        stopWave()
        super.onPause()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        js("window.__native&&window.__native.theme&&window.__native.theme()")
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("window.__nativeBack?window.__nativeBack():false") { r ->
            if (r != "true") moveTaskToBack(true)
        }
    }

    override fun onDestroy() {
        stopWave()
        main.removeCallbacksAndMessages(null)
        controller?.release()
        controller = null
        io.shutdown()
        web.destroy()
        super.onDestroy()
    }

    // ---------- обмен с веб-частью ----------

    private fun js(code: String) {
        if (pageReady) web.evaluateJavascript(code, null)
    }

    private fun push() {
        val c = controller ?: return
        if (!pageReady) return
        val id = c.currentMediaItem?.mediaId ?: ""
        val dur = if (c.duration > 0) c.duration else 0L
        val state = "{\"playing\":${c.isPlaying},\"pos\":${c.currentPosition},\"dur\":$dur,\"id\":\"$id\"}"
        web.evaluateJavascript(
            "window.__native&&window.__native.state&&window.__native.state($state)",
            null
        )
    }

    private fun handleError() {
        val c = controller ?: return
        errCount++
        if (c.mediaItemCount > 1 && errCount < c.mediaItemCount && errCount < 20) {
            c.seekToNextMediaItem()
            c.prepare()
            c.play()
        } else {
            Toast.makeText(this, "Не удалось воспроизвести файл", Toast.LENGTH_SHORT).show()
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun hasPermission(): Boolean = hasAudioPermission()

        @JavascriptInterface
        fun requestPermission() {
            runOnUiThread { requestAudioPermission() }
        }

        @JavascriptInterface
        fun isNight(): Boolean =
            (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES

        @JavascriptInterface
        fun setBars(dark: Boolean) {
            runOnUiThread { applyBars(dark) }
        }

        @JavascriptInterface
        fun listAudio(): String = queryAudio()

        @JavascriptInterface
        fun playQueue(json: String, index: Int) {
            runOnUiThread { startQueue(json, index) }
        }

        @JavascriptInterface
        fun play() {
            runOnUiThread { controller?.play() }
        }

        @JavascriptInterface
        fun pause() {
            runOnUiThread { controller?.pause() }
        }

        @JavascriptInterface
        fun stop() {
            runOnUiThread {
                controller?.let {
                    it.stop()
                    it.clearMediaItems()
                }
            }
        }

        @JavascriptInterface
        fun next() {
            runOnUiThread { controller?.seekToNext() }
        }

        @JavascriptInterface
        fun prev() {
            runOnUiThread { controller?.seekToPrevious() }
        }

        @JavascriptInterface
        fun seekTo(ms: Double) {
            runOnUiThread { controller?.seekTo(ms.toLong()) }
        }

        @JavascriptInterface
        fun setSpeed(s: Double) {
            runOnUiThread {
                speed = s.toFloat()
                controller?.setPlaybackParameters(PlaybackParameters(speed, pitch))
            }
        }

        @JavascriptInterface
        fun setTempo(s: Double, p: Double) {
            runOnUiThread {
                speed = s.toFloat()
                pitch = p.toFloat()
                controller?.setPlaybackParameters(PlaybackParameters(speed, pitch))
            }
        }

        @JavascriptInterface
        fun setWave(on: Boolean) {
            runOnUiThread {
                waveWanted = on
                if (on) startWave() else stopWave()
            }
        }

        @JavascriptInterface
        fun setShuffle(on: Boolean) {
            runOnUiThread {
                shuffle = on
                controller?.setShuffleModeEnabled(on)
            }
        }

        @JavascriptInterface
        fun setMeta(id: String, title: String, artist: String, cover: String) {
            runOnUiThread { updateMeta(id, title, artist, cover) }
        }

        @JavascriptInterface
        fun sleepIn(minutes: Int) {
            runOnUiThread {
                sleepRunnable?.let { main.removeCallbacks(it) }
                sleepRunnable = null
                if (minutes > 0) {
                    val r = Runnable { controller?.pause() }
                    sleepRunnable = r
                    main.postDelayed(r, minutes * 60_000L)
                }
            }
        }

        @JavascriptInterface
        fun deleteAudio(id: String) {
            runOnUiThread { requestDelete(id) }
        }

        @JavascriptInterface
        fun setRepeat(mode: Int) {
            runOnUiThread {
                repeat = when (mode) {
                    0 -> Player.REPEAT_MODE_OFF
                    2 -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_ALL
                }
                controller?.repeatMode = repeat
            }
        }

        @JavascriptInterface
        fun haptic() {
            runOnUiThread { web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) }
        }

        @JavascriptInterface
        fun thumb(id: String, big: Boolean) {
            io.execute {
                val b = loadThumbBytes(id, if (big) 640 else 192)
                val data = if (b != null) "data:image/jpeg;base64," + Base64.encodeToString(b, Base64.NO_WRAP) else ""
                val code = "window.__native&&window.__native.thumb&&window.__native.thumb(" +
                    JSONObject.quote(id) + "," + JSONObject.quote(data) + "," + big + ")"
                main.post { web.evaluateJavascript(code, null) }
            }
        }

        @JavascriptInterface
        fun saveTags(id: String, title: String, artist: String, cover: String) {
            runOnUiThread { requestTags(id, title, artist, cover) }
        }
    }

    // ---------- права, системные панели ----------

    private fun hasAudioPermission(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestAudioPermission() {
        val perms = if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        val asked = prefs.getBoolean("asked", false)
        val blocked = asked && !hasAudioPermission() && perms.none { shouldShowRequestPermissionRationale(it) }
        if (blocked) {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        } else {
            prefs.edit().putBoolean("asked", true).apply()
            requestPermissions(perms, REQ_PERM)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_REC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && waveWanted) {
                startWave()
            } else {
                waveWanted = false
                js("window.__native&&window.__native.waveFail&&window.__native.waveFail()")
            }
        }
        if (requestCode == REQ_PERM) {
            js("window.__native&&window.__native.permission&&window.__native.permission(${hasAudioPermission()})")
        }
    }

    // ---------- волна под музыку ----------

    private fun stopWave() {
        try {
            viz?.setEnabled(false)
            viz?.release()
        } catch (e: Exception) {
            // не критично
        }
        viz = null
    }

    private fun startWave() {
        stopWave()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_REC)
            return
        }
        val sid = PlaybackService.exo?.audioSessionId ?: 0
        if (sid == 0) {
            js("window.__native&&window.__native.waveFail&&window.__native.waveFail()")
            return
        }
        try {
            val v = Visualizer(sid)
            val range = Visualizer.getCaptureSizeRange()
            v.setCaptureSize(512.coerceIn(range[0], range[1]))
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                    if (waveform == null || waveform.size < 48) return
                    val n = 48
                    val step = waveform.size / n
                    val sb = StringBuilder("[")
                    for (i in 0 until n) {
                        val b = (waveform[i * step].toInt() and 0xFF) - 128
                        sb.append(b)
                        if (i < n - 1) sb.append(',')
                    }
                    sb.append(']')
                    val code = "window.__native&&window.__native.wave&&window.__native.wave($sb)"
                    main.post { js(code) }
                }

                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, samplingRate: Int) {}
            }, Visualizer.getMaxCaptureRate(), true, false)
            v.setEnabled(true)
            viz = v
        } catch (e: Exception) {
            stopWave()
            js("window.__native&&window.__native.waveFail&&window.__native.waveFail()")
        }
    }

    private fun applyBars(dark: Boolean) {
        val col = if (dark) Color.parseColor("#0B0C0E") else Color.parseColor("#FDFDFF")
        window.statusBarColor = col
        window.navigationBarColor = col
        val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
            WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(if (dark) 0 else mask, mask)
        web.setBackgroundColor(col)
    }

    // ---------- список аудио с телефона ----------

    private fun queryAudio(): String {
        val arr = JSONArray()
        if (!hasAudioPermission()) return arr.toString()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val cols = arrayListOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.RELATIVE_PATH,
            MediaStore.Audio.Media.IS_RINGTONE,
            MediaStore.Audio.Media.IS_NOTIFICATION,
            MediaStore.Audio.Media.IS_ALARM
        )
        if (Build.VERSION.SDK_INT >= 31) cols.add(MediaStore.Audio.Media.IS_RECORDING)
        try {
            val order = MediaStore.Audio.Media.DATE_ADDED + " DESC"
            contentResolver.query(uri, cols.toTypedArray(), null, null, order)?.use { c ->
                val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val iDate = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val iName = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val iMime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val iRel = c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH)
                val iRing = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_RINGTONE)
                val iNotif = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_NOTIFICATION)
                val iAlarm = c.getColumnIndexOrThrow(MediaStore.Audio.Media.IS_ALARM)
                val iRec = if (Build.VERSION.SDK_INT >= 31) {
                    c.getColumnIndex(MediaStore.Audio.Media.IS_RECORDING)
                } else {
                    -1
                }
                while (c.moveToNext()) {
                    val name = c.getString(iName) ?: ""
                    val mime = (c.getString(iMime) ?: "").lowercase()
                    val rel = (c.getString(iRel) ?: "").lowercase()
                    val low = rel + name.lowercase()
                    var title = c.getString(iTitle) ?: ""
                    if (title.isBlank()) title = name.substringBeforeLast('.')
                    var artist = c.getString(iArtist) ?: ""
                    if (artist == MediaStore.UNKNOWN_STRING) artist = ""
                    val recording = iRec >= 0 && c.getInt(iRec) == 1
                    val tone = c.getInt(iRing) == 1 || c.getInt(iNotif) == 1 || c.getInt(iAlarm) == 1
                    val kind = when {
                        recording || VOICE_RE.containsMatchIn(low) ||
                            mime.contains("amr") || name.lowercase().endsWith(".opus") -> "voice"
                        tone -> "other"
                        else -> "music"
                    }
                    val o = JSONObject()
                    o.put("id", c.getLong(iId))
                    o.put("title", title)
                    o.put("artist", artist)
                    o.put("dur", c.getLong(iDur))
                    o.put("da", c.getLong(iDate))
                    o.put("kind", kind)
                    arr.put(o)
                }
            }
        } catch (e: Exception) {
            // оставляем то, что успели прочитать
        }
        return arr.toString()
    }

    // ---------- плеер ----------

    private fun buildItem(id: String): MediaItem {
        val m = meta[id]
        val md = MediaMetadata.Builder()
        if (m != null) {
            md.setTitle(m.title)
            if (m.artist.isNotBlank()) md.setArtist(m.artist)
        }
        val cv = m?.cover ?: artCache[id]
        if (cv != null) md.setArtworkData(cv, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
        return MediaItem.Builder()
            .setMediaId(id)
            .setUri(audioUri(id))
            .setMediaMetadata(md.build())
            .build()
    }

    private fun startQueue(json: String, index: Int) {
        val c = controller
        if (c == null) {
            Toast.makeText(this, "Плеер ещё запускается, попробуй ещё раз", Toast.LENGTH_SHORT).show()
            return
        }
        val arr = JSONArray(json)
        if (arr.length() == 0) return
        ensureNotifPermission()
        val startId = arr.getJSONObject(index.coerceIn(0, arr.length() - 1)).getString("id")
        if (!artCache.containsKey(startId) && meta[startId]?.cover == null) {
            loadThumbBytes(startId, 512)?.let { artCache[startId] = it }
        }
        artTried.add(startId)
        val from = (index - 200).coerceAtLeast(0)
        val to = (from + 1000).coerceAtMost(arr.length())
        val items = ArrayList<MediaItem>()
        for (i in from until to) {
            val o = arr.getJSONObject(i)
            val id = o.getString("id")
            meta[id] = Meta(o.optString("title"), o.optString("artist"), meta[id]?.cover)
            items.add(buildItem(id))
        }
        c.setMediaItems(items, index - from, 0L)
        c.setShuffleModeEnabled(shuffle)
        c.repeatMode = repeat
        c.setPlaybackParameters(PlaybackParameters(speed, pitch))
        c.prepare()
        c.play()
    }

    private fun updateMeta(id: String, title: String, artist: String, cover: String) {
        val bytes: ByteArray? = decodeDataUri(cover)
        val old = meta[id]
        meta[id] = Meta(title, artist, bytes)
        if (old != null && old.title == title && old.artist == artist && old.cover.contentEquals(bytes)) return
        val c = controller ?: return
        for (i in 0 until c.mediaItemCount) {
            if (c.getMediaItemAt(i).mediaId == id) {
                replaceKeepingPlayback(c, i, buildItem(id))
                break
            }
        }
    }

    /** Меняет элемент очереди и не даёт текущему треку остановиться: позиция и «играет» сохраняются. */
    private fun replaceKeepingPlayback(c: Player, i: Int, item: MediaItem) {
        val cur = i == c.currentMediaItemIndex
        val want = c.playWhenReady
        val pos = c.currentPosition
        c.replaceMediaItem(i, item)
        if (cur) {
            c.seekTo(i, pos)
            if (c.playbackState == Player.STATE_IDLE) c.prepare()
            if (want) c.play()
        }
    }

    private fun removeFromQueue(id: String) {
        val c = controller ?: return
        for (i in c.mediaItemCount - 1 downTo 0) {
            if (c.getMediaItemAt(i).mediaId == id) c.removeMediaItem(i)
        }
    }

    // ---------- обложки из файлов, теги ----------

    private fun audioUri(id: String): Uri =
        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toLong())

    private fun loadThumbBytes(id: String, size: Int): ByteArray? {
        return try {
            val bmp = contentResolver.loadThumbnail(audioUri(id), Size(size, size), null)
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 86, bos)
            bos.toByteArray()
        } catch (e: Exception) {
            null
        }
    }

    private fun decodeDataUri(cover: String): ByteArray? {
        if (!cover.startsWith("data:")) return null
        return try {
            Base64.decode(cover.substringAfter(","), Base64.DEFAULT)
        } catch (e: Exception) {
            null
        }
    }

    /** Заранее подгружаем обложку для уведомления: текущий, следующий и предыдущий трек. */
    private fun preloadArt() {
        val c = controller ?: return
        val idxs = ArrayList<Int>()
        idxs.add(c.currentMediaItemIndex)
        val n = c.nextMediaItemIndex
        if (n != C.INDEX_UNSET) idxs.add(n)
        val p = c.previousMediaItemIndex
        if (p != C.INDEX_UNSET) idxs.add(p)
        for (i in idxs) {
            if (i < 0 || i >= c.mediaItemCount) continue
            val mi = c.getMediaItemAt(i)
            val id = mi.mediaId
            if (mi.mediaMetadata.artworkData != null || artTried.contains(id)) continue
            artTried.add(id)
            io.execute {
                val b = loadThumbBytes(id, 512)
                if (b != null) main.post { applyArt(id, b) }
            }
        }
    }

    private fun applyArt(id: String, bytes: ByteArray) {
        artCache[id] = bytes
        val c = controller ?: return
        for (i in 0 until c.mediaItemCount) {
            val mi = c.getMediaItemAt(i)
            if (mi.mediaId == id && mi.mediaMetadata.artworkData == null) {
                val md = mi.mediaMetadata.buildUpon()
                    .setArtworkData(bytes, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
                    .build()
                replaceKeepingPlayback(c, i, mi.buildUpon().setMediaMetadata(md).build())
                break
            }
        }
    }

    private fun ensureNotifPermission() {
        if (Build.VERSION.SDK_INT < 33 || notifAsked) return
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) return
        notifAsked = true
        val prefs = getSharedPreferences("app", MODE_PRIVATE)
        val canAsk = !prefs.getBoolean("notifAsked", false) ||
            shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)
        if (canAsk) {
            prefs.edit().putBoolean("notifAsked", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        } else {
            Toast.makeText(
                this,
                "Включи уведомления для Mcmusic, чтобы плеер был виден у камеры и на экране блокировки",
                Toast.LENGTH_LONG
            ).show()
            try {
                startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                )
            } catch (e: Exception) {
                // не критично
            }
        }
    }

    private fun requestTags(id: String, title: String, artist: String, cover: String) {
        try {
            val pi = MediaStore.createWriteRequest(contentResolver, listOf(audioUri(id)))
            pendingTags = PendingTags(id, title, artist, decodeDataUri(cover))
            startIntentSenderForResult(pi.intentSender, REQ_WRITE, null, 0, 0, 0)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось записать в файл. Изменения сохранены только в приложении", Toast.LENGTH_LONG).show()
        }
    }

    private fun writeTags(p: PendingTags): String {
        val uri = audioUri(p.id)
        var name = ""
        var mime = ""
        try {
            contentResolver.query(
                uri,
                arrayOf(MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.MIME_TYPE),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    name = c.getString(0) ?: ""
                    mime = c.getString(1) ?: ""
                }
            }
        } catch (e: Exception) {
            // оставим пустыми
        }
        val isMp3 = mime.equals("audio/mpeg", ignoreCase = true) || name.endsWith(".mp3", ignoreCase = true)
        var fileOk = false
        if (isMp3) {
            try {
                Id3.write(contentResolver, uri, cacheDir, p.title, p.artist, p.cover)
                fileOk = true
            } catch (e: Exception) {
                fileOk = false
            }
        }
        var dbOk = false
        try {
            val v = ContentValues()
            v.put(MediaStore.Audio.Media.TITLE, p.title)
            v.put(MediaStore.Audio.Media.ARTIST, p.artist)
            contentResolver.update(uri, v, null, null)
            dbOk = true
        } catch (e: Exception) {
            dbOk = false
        }
        return when {
            fileOk -> "Записано в файл: название, исполнитель и обложка"
            isMp3 -> "Не удалось записать в файл. Изменения сохранены только в приложении"
            dbOk -> "Название и исполнитель сохранены на телефоне. Обложка для этого формата хранится только в приложении"
            else -> "Изменения сохранены только в приложении"
        }
    }

    private fun reloadItem(id: String, resume: Boolean) {
        val c = controller ?: return
        for (i in 0 until c.mediaItemCount) {
            if (c.getMediaItemAt(i).mediaId == id) {
                val cur = i == c.currentMediaItemIndex
                replaceKeepingPlayback(c, i, buildItem(id))
                if (cur && resume) c.play()
                break
            }
        }
    }

    // ---------- удаление файла с телефона ----------

    private fun requestDelete(id: String) {
        try {
            val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toLong())
            val pi = MediaStore.createDeleteRequest(contentResolver, listOf(uri))
            pendingDeleteId = id
            startIntentSenderForResult(pi.intentSender, REQ_DELETE, null, 0, 0, 0)
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось удалить файл", Toast.LENGTH_LONG).show()
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_DELETE -> {
                val id = pendingDeleteId
                pendingDeleteId = null
                if (resultCode == RESULT_OK && id != null) {
                    removeFromQueue(id)
                    js("window.__native&&window.__native.deleted&&window.__native.deleted(\"$id\")")
                }
            }
            REQ_WRITE -> {
                val p = pendingTags
                pendingTags = null
                if (p != null) {
                    if (resultCode == RESULT_OK) {
                        val c = controller
                        val wasPlaying = c != null && c.playWhenReady && c.currentMediaItem?.mediaId == p.id
                        if (wasPlaying) c?.pause()
                        io.execute {
                            val msg = writeTags(p)
                            main.post {
                                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                                reloadItem(p.id, wasPlaying)
                            }
                        }
                    } else {
                        Toast.makeText(this, "Изменения сохранены только в приложении", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            REQ_FILE -> {
                fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                fileCb = null
            }
        }
    }
}
