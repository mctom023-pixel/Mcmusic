package app.mcmusic

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * 8D: звук медленно ездит между левым и правым ухом (в наушниках слышно лучше всего).
 * Работает для стерео 16 бит; для остальных форматов просто не включается.
 * level: 0 выкл, 1 мягкий (круг около 12 с), 2 сильный (около 6 с).
 */
class Pan8D : BaseAudioProcessor() {

    @Volatile
    var level = 0

    private var rate = 44100
    private var phase = 0.0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount != 2) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        rate = inputAudioFormat.sampleRate
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return
        val out = replaceOutputBuffer(remaining)
        val lv = level
        if (lv == 0) {
            out.put(inputBuffer)
        } else {
            val step = 2.0 * PI * (if (lv == 1) 0.08 else 0.16) / rate
            val frames = remaining / 4
            for (i in 0 until frames) {
                val l = inputBuffer.short.toInt()
                val r = inputBuffer.short.toInt()
                phase += step
                if (phase > 2.0 * PI) phase -= 2.0 * PI
                val ang = (sin(phase) + 1.0) * 0.25 * PI
                val gl = cos(ang) * 1.4142
                val gr = sin(ang) * 1.4142
                val m = (l + r) * 0.5
                val ol = 0.3 * l + 0.7 * m * gl
                val orr = 0.3 * r + 0.7 * m * gr
                out.putShort(clamp(ol))
                out.putShort(clamp(orr))
            }
            while (inputBuffer.hasRemaining()) out.put(inputBuffer.get())
        }
        out.flip()
    }

    private fun clamp(v: Double): Short = v.coerceIn(-32768.0, 32767.0).toInt().toShort()
}
