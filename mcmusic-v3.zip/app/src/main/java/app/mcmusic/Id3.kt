package app.mcmusic

import android.content.ContentResolver
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * Запись тегов ID3v2.3 (название, исполнитель, обложка) прямо в MP3-файл.
 * Остальные кадры старой метки (альбом, год и т. д.) сохраняются.
 */
object Id3 {

    private fun readFully(input: InputStream, buf: ByteArray): Int {
        var off = 0
        while (off < buf.size) {
            val n = input.read(buf, off, buf.size - off)
            if (n < 0) break
            off += n
        }
        return off
    }

    private fun syncsafe(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0x7F) shl 21) or ((b[o + 1].toInt() and 0x7F) shl 14) or
            ((b[o + 2].toInt() and 0x7F) shl 7) or (b[o + 3].toInt() and 0x7F)

    private fun be32(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or
            ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)

    private fun putBe32(out: OutputStream, v: Int) {
        out.write((v ushr 24) and 0xFF)
        out.write((v ushr 16) and 0xFF)
        out.write((v ushr 8) and 0xFF)
        out.write(v and 0xFF)
    }

    private fun putSyncsafe(out: OutputStream, v: Int) {
        out.write((v ushr 21) and 0x7F)
        out.write((v ushr 14) and 0x7F)
        out.write((v ushr 7) and 0x7F)
        out.write(v and 0x7F)
    }

    private fun frame(out: OutputStream, id: String, body: ByteArray) {
        out.write(id.toByteArray(Charsets.ISO_8859_1))
        putBe32(out, body.size)
        out.write(0)
        out.write(0)
        out.write(body)
    }

    private fun textBody(s: String): ByteArray {
        val bo = ByteArrayOutputStream()
        bo.write(1)
        bo.write(0xFF)
        bo.write(0xFE)
        bo.write(s.toByteArray(Charsets.UTF_16LE))
        return bo.toByteArray()
    }

    fun write(
        resolver: ContentResolver,
        uri: Uri,
        cacheDir: File,
        title: String,
        artist: String,
        cover: ByteArray?
    ) {
        // 1. читаем старую метку и запоминаем кадры, которые не трогаем
        var oldTotal = 0
        val keep = ByteArrayOutputStream()
        val head = ByteArray(10)
        val first = resolver.openInputStream(uri) ?: throw IllegalStateException("нет доступа к файлу")
        first.use { input ->
            val n = readFully(input, head)
            val isId3 = n == 10 &&
                head[0].toInt() == 'I'.code && head[1].toInt() == 'D'.code && head[2].toInt() == '3'.code &&
                (head[3].toInt() == 2 || head[3].toInt() == 3 || head[3].toInt() == 4)
            if (isId3) {
                val ver = head[3].toInt()
                val flags = head[5].toInt() and 0xFF
                val size = syncsafe(head, 6)
                if (size < 0 || size > 64 * 1024 * 1024) throw IllegalStateException("повреждённая метка")
                oldTotal = 10 + size + (if (ver == 4 && (flags and 0x10) != 0) 10 else 0)
                if ((ver == 3 || ver == 4) && (flags and 0xC0) == 0) {
                    val body = ByteArray(size)
                    readFully(input, body)
                    var pos = 0
                    while (pos + 10 <= size) {
                        if (body[pos].toInt() == 0) break
                        val id = String(body, pos, 4, Charsets.ISO_8859_1)
                        val fsz = if (ver == 4) syncsafe(body, pos + 4) else be32(body, pos + 4)
                        val f0 = body[pos + 8].toInt() and 0xFF
                        val f1 = body[pos + 9].toInt() and 0xFF
                        if (fsz < 0 || pos + 10 + fsz > size) break
                        val drop = id == "TIT2" || id == "TPE1" || id == "APIC" ||
                            (ver == 4 && (f0 != 0 || f1 != 0))
                        if (!drop) {
                            keep.write(body, pos, 4)
                            putBe32(keep, fsz)
                            keep.write(f0)
                            keep.write(f1)
                            keep.write(body, pos + 10, fsz)
                        }
                        pos += 10 + fsz
                    }
                }
            }
        }

        // 2. собираем новую метку
        val frames = ByteArrayOutputStream()
        frames.write(keep.toByteArray())
        if (title.isNotEmpty()) frame(frames, "TIT2", textBody(title))
        if (artist.isNotEmpty()) frame(frames, "TPE1", textBody(artist))
        if (cover != null && cover.isNotEmpty()) {
            val pb = ByteArrayOutputStream()
            pb.write(0)
            pb.write("image/jpeg".toByteArray(Charsets.ISO_8859_1))
            pb.write(0)
            pb.write(3)
            pb.write(0)
            pb.write(cover)
            frame(frames, "APIC", pb.toByteArray())
        }
        val tagBody = frames.toByteArray()

        // 3. во временный файл: новая метка + звук без старой метки
        val tmp = File.createTempFile("tag", ".mp3", cacheDir)
        try {
            FileOutputStream(tmp).use { out ->
                out.write("ID3".toByteArray(Charsets.ISO_8859_1))
                out.write(3)
                out.write(0)
                out.write(0)
                putSyncsafe(out, tagBody.size)
                out.write(tagBody)
                val src = resolver.openInputStream(uri) ?: throw IllegalStateException("нет доступа к файлу")
                src.use { s ->
                    var toSkip = oldTotal.toLong()
                    while (toSkip > 0) {
                        val k = s.skip(toSkip)
                        if (k <= 0) {
                            if (s.read() < 0) break
                            toSkip -= 1
                        } else {
                            toSkip -= k
                        }
                    }
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = s.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                    }
                }
            }
            // 4. кладём результат на место файла
            val dst = resolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("нет записи в файл")
            dst.use { o -> FileInputStream(tmp).use { i -> i.copyTo(o) } }
        } finally {
            tmp.delete()
        }
    }
}
